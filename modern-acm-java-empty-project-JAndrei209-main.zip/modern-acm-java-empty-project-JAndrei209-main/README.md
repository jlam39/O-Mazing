# 129 Starter Files
Starter Project for any ACM Project from COMP 129

For your edu game project, use this readme to state your *project's goals* and **what you will be proposing to build**.
You'll also be using the readme to provide seperate page that will contain an analysis of what you are focusing on, and to provide findings for your project.

Please also make sure to **setup the three milestones** in zenhub to represent the sprints.  Each sprint will last a week.
The first milestone will be sprint #1.
Each sprint will last a week (it's ok to have the dates overlap, since we will finish one sprint and start the next).

You will use this project as your base.
Make sure that you understand the two files provided here

## UML Class Diagram for files provided
![](media/55GroupProjectUML.jpg)

## UML Sequence Diagram for files provided
![](media/55GroupProjectSequenceDiagram.png)
